const PageEnum = {
  SiteWrapper: {
    SEARCH: document.querySelector(`.columns__search-item`),
    rating: document.querySelector(`.columns__rating`)
  }
};
