const RATING_LIST = {
  'names': [
    `User`,
    `Jason`,
    `WeatherBot`,
  ],
  'ratings': [
    10,
    9.4,
    2.6,
    6.5
  ]
};
