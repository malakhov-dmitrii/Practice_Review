class Search extends Component {
  constructor() {
    super();
    this._onChange = null;
  }

  // It is not necessary to include invisible button, we can submit form hitting 'enter' key
  get template() {
    return `<input type="text" name="search" placeholder="Search">
      <button type="submit" class="visually-hidden">Search</button>`.trim();
  }

  removeEventListener() {
    // This event listener should use the same event which was used with addEventListener,
    // otherwise this listener will be never removed
    this._element
      .removeEventListener(`keydown`, this._onSearchChange);
  }

  _onSearchChange(event) {
    if (typeof this._onChange === `function`) {
      this._onChange(event.target.value);
    }
  }

  set onChange(fn) {
    this._onChange = fn;
  }

  setEventListener() {
    // Usually it is better to use 'keypress' action as far as it leads to less bugs handling user input
    // you can refer to this stackoverflow answer
    // https://stackoverflow.com/questions/3396754/onkeypress-vs-onkeyup-and-onkeydown
    this._element
      .addEventListener(`keyup`, this._onSearchChange);
  }

}
