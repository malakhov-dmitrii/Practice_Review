class Person extends Component {
    constructor(name) {
        super();
        this.name = name;
        this._happiness = 0;
        this._valueElement = document.querySelector(`.column__value-name`);
        this._iconElement = document.querySelector(`.column__value-icon`);
    }

    // Methods down below all return numbers but its names starting from 'has'
    // which usually means it should return boolean

    // Plus this code is completely repetitive,
    // these methods can be replaced by one
    // and use of them would also become clearer
    hasCat() {
        return this._happiness++;
    }

    hasRest() {
        return this._happiness++;
    }

    hasMoney() {
        return this._happiness++;
    }

    // Method return number but its name starting from 'is'
    // which usually means it should return boolean
    isSunny() {
        const APIKey = '28c7d687accc7c75aabbc7fb71173feb';
        const city = 'Москва';
        const url = 'http://api.openweathermap.org/data/2.5/weather?q=' + city + '&appid=' + APIKey;

        return fetch(url)
            .then(res => res.json())
            .then((res) => {
              console.log(this._happiness);
                if (res.main.temp - 273 > 15) {
                    return this._happiness++;
                }
            });
      // There is unhandled error case from fetch
      // It would be better if we will catch it some way
      }
}
