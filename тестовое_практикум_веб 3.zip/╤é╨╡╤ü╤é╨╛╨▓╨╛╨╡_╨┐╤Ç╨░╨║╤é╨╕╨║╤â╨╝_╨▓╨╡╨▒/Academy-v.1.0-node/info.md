# Test task. Web developer.

## Description for reviewer
##

**A student is given the task to implement a REST API that supports CRUD operations for creating articles. The user should be able to:**

- Get all articles.
- Get a specific article by ID.
- Create an article.
- Edit an article.
- Delete an article.

**The API should be a GIT repository with a clear README.**
**The repository structure and code must be commented. Private comments can be made in relevant files (provided the file format allows for them). General comments should be made at the end of the app.js file.**

## When checking the project, ask yourself the following questions:
##

- Are correct responses returned for all requests?
- Are errors handled properly?
- Do all requests correspond to REST?
- Are error codes correct?
- Is all data that's received validated correctly?
- Code: how would you restructure it?
- Security: can data be unintentionally written to the DB and is there a way to perform an SQL injection?
- Infrastructure issues: is everything fine with .gitignore and package.json? Is everything easy to use in development mode?

