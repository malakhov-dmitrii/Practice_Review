# REST API in Node.js

**Technology used**

* Node.js
* Express.js
* SQLite

**Available routes**

`GET /api/articles` — Get all articles.
`GET /api/article/:id` — Get a specific article by ID.
`POST /api/article` — Create an article.
`PUT /api/article/:id` — Edit an article.
`DELETE /api/article/:id` — Delete an article by ID.

